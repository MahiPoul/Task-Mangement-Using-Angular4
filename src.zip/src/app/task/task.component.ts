import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { DataService } from '../data.service';
import 'rxjs/add/observable/bindCallback';
import { Subscription } from 'rxjs/Subscription';
@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  shoppingitemlist: Item[] = [];
  labelset: String[] = ['personal', 'work', 'shopping', 'others'];
  statusset: String[] = ['new', 'inprogress' , 'completed'];
  selecteditem: Item;
  drop: String;
  toogle: Boolean = false;
  constructor(private dataService: DataService) { }
  getitems() {
    this.dataService.getshoppingitems()
      .subscribe(items => {
        this.shoppingitemlist = items;
        console.log('data from dataservice =>' + items[0].status);
      });
  }

  additem(form) {
    const newitem: Item = {
      labe: form.value.labe,
      duedate: form.value.duedate,
      status: form.value.status,
      tasktype: form.value.tasktype,
      priyority: form.value.priyority
    };

    this.dataService.addshoppingitem(newitem)
      .subscribe(item => {
        this.getitems();
      });

  }

  deleteitem(id) {
    this.dataService.deleteshoppingitem(id)
      .subscribe(data => {
        console.log(data);
        if (data.n === 1) {
          for (let i = 0; i < this.shoppingitemlist.length; i++) {
            if (id === this.shoppingitemlist[i]._id) {
              this.shoppingitemlist.splice(i, 1);
            }
          }
        }
      });
  }

  edititem(form) {
    const newitem: Item = {
      _id: this.selecteditem._id,
      labe: form.value.labe,
      duedate: this.selecteditem.duedate,
      status: form.value.status,
      tasktype: this.selecteditem.tasktype,
      priyority: this.selecteditem.priyority
    };

    this.dataService.updateshoppingitem(newitem)
      .subscribe(result => {
        this.getitems();
      });
    this.toogle = !this.toogle;
  }

  updateitemcheckbox(item) {
    item.priyority = 'feff';
    this.dataService.updateshoppingitem(item)
      .subscribe(result => {
        this.getitems();
      });
  }
  showeditform(item) {
    this.selecteditem = item;
    this.toogle = !this.toogle;
  }

  ngOnInit() {
    this.getitems();
  }


}
