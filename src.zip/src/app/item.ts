export class Item {
    _id?: String;
    labe: String;
    duedate: Date;
    status: String;
    tasktype: String;
    priyority: Boolean;
// tslint:disable-next-line:eofline
}
