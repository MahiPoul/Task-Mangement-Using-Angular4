import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class DataService {


  constructor(private http: Http) { }

  addshoppingitem(newitem) {
    const headers = new Headers();
    headers.append('content.Type', 'application/json');
    return this.http.post('http://localhost:3000/api/item', newitem, { headers: headers })
      .map(res => res.json());
  }


  getshoppingitems() {
    return this.http.get('http://localhost:3000/api/items')
      .map(res => res.json());
  }

  deleteshoppingitem(id) {
    return this.http.delete('http://localhost:3000/api/item/' + id)
      .map(res => res.json());
  }

  updateshoppingitem(newitem) {
    const headers = new Headers();
    headers.append('content.Type', 'application/json');
    return this.http.put('http://localhost:3000/api/item/' + newitem._id, newitem, { headers: headers })
      .map(res => res.json());
  }


}
