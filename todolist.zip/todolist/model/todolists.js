const mongoose = require('mongoose');
const todolistschema = mongoose.Schema({
    labe: {
        type: String,
        required: true
    },
    duedate: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    tasktype: {
        type: String,
        required: true
    },
    priyority: {
        type: Boolean,
        required: true
    }
});
console.log("hai entry todo model");
const item = module.exports = mongoose.model('item', todolistschema);