var express = require('express');
var router = express.Router();
const item = require('../model/todolists');

router.get('/items', (req, res, next) => {
    // res.send('get get router tested');
    item.find(function(err, items) {
        if (err) {
            res.json(err);
        } else {
            res.json(items);
        }
    });
});

router.post('/item', (req, res, next) => {
    //res.send('post get router tested');
    let newshoppingitem = new item({
        labe: req.body.labe,
        duedate: req.body.duedate,
        status: req.body.status,
        tasktype: req.body.tasktype,
        priyority: req.body.priyority
    });
    newshoppingitem.save((err, item) => {
        if (err) {
            res.json(err);
        } else {
            res.json({ msg: 'item added sucessfully' });
        }
    });
});
router.put('/item/:id', (req, res, next) => {
    // res.send('put get router tested');
    item.findOneAndUpdate({ _id: req.params.id }, {
            $set: {
                labe: req.body.labe,
                duedate: req.body.duedate,
                status: req.body.status,
                tasktype: req.body.tasktype,
                priyority: req.body.priyority
            }
        },
        function(err, result) {
            if (err) {
                res.json(err);
            } else {
                res.json(result);
            }
        })
});
router.delete('/item/:id', (req, res, next) => {
    //res.send('delete get router tested');
    item.remove({ _id: req.params.id }, function(err, result) {
        if (err) {
            res.json(err);
        } else {
            res.json(result);
        }
    })
});
module.exports = router;